package de.vogella.junit.first;

public class MyClass {
	  public int multiply(int x, int y) {
	    return x * y;
	  }
	} 

