package de.vogella.junit.first;

public class aUser {

	public aUser(String string, String string2) {
		// TODO Auto-generated constructor stub
	}

	public static String getUsername() {
		// TODO Auto-generated method stub
		return null;
	}

	public static Object getPassword() {
		// TODO Auto-generated method stub
		return null;
	}

}
