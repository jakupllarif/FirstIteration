package de.vogella.junit.first;

public enum XO_Enum {

}
