package de.vogella.junit.first;

import org.junit.Test;

import static org.junit.Assert.assertEquals;


public class LoginProjectController {
	@Test
	  public void testLogin() {
//		LoginProjectController tester = new LoginProjectControllers();
//	    assertEquals("Result", 2, tester.println 2);
	}
}


	
